var express = require('express');
var mysql = require('mysql');
var path = require('path');
var session = require('express-session');
var bodyParser = require('body-parser');
var fs = require('fs');
var sh = require('shelljs');
var dockerHubAPI = require('docker-hub-api');
var HashTable = require('hashtable');
var DOCKER_HUB_USERNAME="hash14";
var DOCKER_HUB_PASSWORD="chishash14";
var K8s = require('k8s');


/////////////////////////////////////////////////////////////////////////////////////////////////importing modules;

dockerHubAPI.setCacheOptions({enabled: true, time: 60}); // This will enable the cache and cache things for 60 seconds 

dockerHubAPI.login(DOCKER_HUB_USERNAME, DOCKER_HUB_PASSWORD).then(function(info) {
    console.log(`My Docker Hub login token is '${info.token}'!`);
});

// use kubectl 
 
var kubectl = K8s.kubectl({
    endpoint:  'http://193.55.95.225:8085'
    , namespace: 'namespace'
    , binary: '/usr/local/bin/kubectl'
})
 
//use restful api 
var kubeapi = K8s.api({
    endpoint: 'http://193.55.95.225:8085'
    , version: '/api/v1'
})
 
// Configure using kubeconfig 
var kubeapi = K8s.api({
    kubeconfig: '/etc/cluster1.yaml'
    ,version: '/api/v1'
})
 
var kube = K8s.kubectl({
    binary: '/bin/kubectl'
    ,kubeconfig: '/etc/cluster1.yaml'
    ,version: '/api/v1'
});

var app = express();
var server_port = 3000;
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "chishash14",
  database: "bdlaas_users"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

});

/////////////////////////////////////////////////////////////////////////////////////////////////initializing variables

app.use(bodyParser.urlencoded({ extended : true }));
app.use(session({secret: 'ssshhhhh'}));
app.use(express.static(__dirname + '/'));
app.set('views', path.join(__dirname, 'views')); // here the .ejs files is in views folders
app.set('view engine', 'ejs');

/////////////////////////////////////////////////////////////////////////////////////////////////configuring app settings 

app.post('/home', function(req, res) {//This service is called in "signin and registration page".

req.session.username = req.body.username;

if(req.body.signinpassword == null){//Check if he wants to register or signin.

con.query("Insert into users (name,email,username,password) VALUES ('"+req.body.name+"','"+req.body.email+"','"+req.body.username +"','"+req.body.password+"')",function(err, result){
                                          
	if (err)
	 throw err;

	console.log("User added succesfully");

});//end query

}//end if

var dir = 'users/' + req.session.username;
if (!fs.existsSync(dir)){
	fs.mkdirSync(dir);
}

res.render('home', { //render the index.ejs
  name:req.session.username
  });//end rendering page
});//end post

/////////////////////////////////////////////////////////////////////////////////////////////////

app.get('/checkusername', function(req, res) {//Check if username if exists or not, this service is called in "signin and registration page".
var obj={};

con.query("SELECT * FROM users where username = '" + req.query.username + "'",function(err, result){    

		console.log(req.query.username + " result: " + result.length);
		obj.countuser = result.length;

		res.header('Content-type','application/json');
		res.header('Charset','utf8');
		res.send(req.query.callback + '('+ JSON.stringify(obj) + ');');

	});//end query

});//end get

/////////////////////////////////////////////////////////////////////////////////////////////////

app.get('/checkpassword', function(req, res) {//Check username and password if satisfied or not, Used in signin page.
var obj={};

con.query("SELECT password FROM users where username = '" + req.query.username + "'",function(err, result){    

		console.log(req.query.username + " password: " + result[0].password);
		obj.pass =  result[0].password;
		obj.name = req.query.username;
		res.header('Content-type','application/json');
		res.header('Charset','utf8');
		res.send(req.query.callback + '('+ JSON.stringify(obj) + ');');
		res.end();
	});//end query
});//end get

/////////////////////////////////////////////////////////////////////////////////////////////////

app.post('/createproject', function(req, res) {//Create project directory for user(use "mkdir projectname" and send it to server).
	console.log(req.body.microservices);
	var dir = 'users/' + req.session.username + '/' + req.body.projectname;
	if (!fs.existsSync(dir)){
	    fs.mkdirSync(dir);
	}
	req.session.microservices = req.body.microservices;
	req.session.projectname = req.body.projectname;

	res.render('createproject', { //render the index.ejs
	  microservices:req.body.microservices,
	  projectname:req.body.projectname
	});//end rendering page
	
});//end post

/////////////////////////////////////////////////////////////////////////////////////////////////

app.post('/apacheservice', function(req, res) {//Create Dockerfile, and (build and push to our Docker Hub) image for user.
	var envs = [];
	var apps = [];
	var dir = 'users/' + req.session.username + '/' + req.session.projectname;
	var githublink = req.body.githublink;
	var content = "FROM hash14/apache\nRUN git clone " + githublink + " /var/www/html";
	var imageName = 'hash14/'+ req.session.microservices + '-' + req.session.username + '-' + req.session.projectname;
	fs.writeFile(dir+'/Dockerfile', content, function (err) {
		sh.exec('sudo docker build -t ' + imageName + ' ' + dir, {silent:false}).stdout;
		sh.exec('sudo docker push ' + imageName , {silent:false}).stdout;
		//sh.exec('sudo docker run -d -p '+ port + ':80 '+ imageName +':latest' , {silent:false}).stdout;
		
		if (err) throw err;
		console.log('Saved!');
		//res.end();
	});
	dockerHubAPI.repositories(DOCKER_HUB_USERNAME).then(function(info) {

		for(var i = 0 ; i < info.length ; i++){
			var splitImage = info[i].name.split('/');
			var splitEnvAppUser = splitImage[0].split('-');
			//console.log(splitEnvAppUser[0] + " here " + splitEnvAppUser[2]);
			
			if(splitEnvAppUser[0] == req.session.microservices && splitEnvAppUser[1] == req.session.username){
				apps.push(splitEnvAppUser[2]);
				envs.push(splitEnvAppUser[0]);
			}
		
		}
		req.session.envs = envs;
		req.session.apps = apps;
		console.log(envs + " here " + apps);
		res.render('services', { //render the services.ejs
		  envss:req.session.envs,
		  appss:req.session.apps,
		  microservices:req.session.microservices,
		  projectname:req.session.projectname
		});//end rendering page
		res.end();
	});
		
	
});//end post
app.get('/deletesession', function(req, res) {//Clear all session variables. 
	console.log('Deleting sessions...');
	req.session.destroy();
	res.end();
});//end post

/////////////////////////////////////////////////////////////////////////////////////////////////

app.post('/runapacheapp', function(req, res) {//Run application in Kubernetes after specifying some options .

	console.log('Using Kubernetes');
	kubeapi.get('/namespaces/default/replicationcontrollers', function(err, data){console.log(data + ' errors: ' + err)})

	/*var nbOfReplicas = req.body.nbreplicas;
	var appName = req.session.projectname;
	var imageName = 'hash14/' + req.session.microservices + '-' + req.session.username + '-' +  req.session.projectname;
	if(nbOfReplicas == null)
		nbOfReplicas = 1;
	sh.exec('sudo ssh -i Key/ytaher_vm1_cle_ssh.pem ubuntu@193.55.95.225', {silent:false}).stdout;
	sh.exec('kubectl run ' + appName + '--image=' + imageName + ' --replicas=' + nbOfReplicas + ' --port=80' , {silent:false}).stdout;
	sh.exec('kubectl expose rc ' + appName + ' --type=ClusterIP', {silent:false}).stdout;*/

		
});//end post

/////////////////////////////////////////////////////////////////////////////////////////////////

app.listen(server_port, function(){//Tell the server to listen to server_port. 
	console.log("Listening on port : " + server_port);
});

/////////////////////////////////////////////////////////////////////////////////////////////////end


