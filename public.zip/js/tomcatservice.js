function test(){
var fs = require('fs');

fs.appendFile('/home/hassan/Desktop/Dockerfile', 'Hello content!', function (err) {
  if (err) throw err;
  console.log('Saved!');
});
}
